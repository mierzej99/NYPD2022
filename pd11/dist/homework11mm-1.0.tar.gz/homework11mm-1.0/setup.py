from setuptools import setup

setup(
    name='homework11mm',
    version='1.0',
    description='Homework for python class',
    author='Jan Kowalski',
    install_requires=[
        'numpy', 'os', 'json'
    ],
)
